package navigator;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.navigation.Pose;


/*
 * Simples tests d'utilisation
 */
public class TestOdometry {


	public static void main(String[] args) {
		int cptPose = 1, cptTest = 1;
		
//			System.out.println("Ready to create Robot : press any key");
//			Button.waitForAnyPress();
		RegulatedMotor moteurDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor moteurGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		
		Robot robot = new Robot(moteurGauche, moteurDroite);
	
		Pose pose;

		
		
		System.out.println("Ready to get Pose");
		Button.waitForAnyPress();				
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);
		
//		System.out.println("TEST SQUARE: \ntravel 50cm\nrotate -90°\ntravel -50cm\nrotate -90°\ntravel 50cm\nrotate 90°\ntravel 50cm\nrotate 90°\nPress to start.\n");
//		Button.waitForAnyPress();		
//		robot.pilot.travel(50); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(-50); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(50); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
//		robot.pilot.travel(50); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
		
			
// TEST 1
			System.out.println("TEST " + cptTest++ +": \ntravel 50cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(50); // cm per second

//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
// TEST 2
			System.out.println("TEST " + cptTest++ +": \nrotate 90°\nPress to start.\n");
			Button.waitForAnyPress();
			robot.pilot.rotate(90); // degree clockwise

//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
// TEST 3
			System.out.println("TEST " + cptTest++ +": \ntravel 50cm\nPress to start.\n");
			Button.waitForAnyPress();
			robot.pilot.travel(50);//, true); // move backward for 50 cm - true: method returns immediately
			
//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
			//while(robot.pilot.isMoving()) Thread.yield();

// TEST 4
			System.out.println("TEST " + cptTest++ +": \nrotate 90\nPress to start.\n");
			Button.waitForAnyPress();
			robot.pilot.rotate(90);

//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
// TEST 5
			System.out.println("TEST " + cptTest++ +": \ntravel 50cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(50); // cm per second
			
//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
// TEST 6
			System.out.println("TEST " + cptTest++ +": )\nrotate 90°\nPress to start.\n");
			Button.waitForAnyPress();
			robot.pilot.rotate(90); // degree clockwise

//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
// TEST 7
			System.out.println("TEST " + cptTest++ +": \ntravel 50cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(50); // cm per second

//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
// TEST 8
			System.out.println("TEST " + cptTest++ +": \nrotate 90°\nPress to start.\n");
			Button.waitForAnyPress();
			robot.pilot.rotate(90); // degree clockwise

//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
			
//			System.out.println("TEST 5: rotateTo 180\nPress to start.\n");
//			Button.waitForAnyPress();		
//			robot.pilot.rotateTo(270);

//		System.out.println("TEST 5: \ntravelArc \nradius:100 \ndistance:50\nPress to start.\n");
//		Button.waitForAnyPress();
//		robot.pilot.travelArc(100, 50);
//		
//		System.out.println("TEST 6: \ntravelArc \nradius:10 \ndistance:50\nPress to start.\n");
//		Button.waitForAnyPress();
//		robot.pilot.travelArc(100, 200);
//		
//		System.out.println("TEST 7: \ntravelArc \nradius:20 \ndistance:50\nPress to start.\n");
//		Button.waitForAnyPress();
//		robot.pilot.travelArc(200, 50);
//		
//		System.out.println("TEST 8: \ntravelArc \nradius:40 \ndistance:50\nPress to start.\n");
//		Button.waitForAnyPress();
//		robot.pilot.travelArc(400, 50);
//		
//		System.out.println("TEST 9: \narc \nradius:10 \nangle:180\nPress to start.\n");
//		Button.waitForAnyPress();
//		robot.pilot.arc(10, 180);
//		
//		System.out.println("TEST 10: \narc \nradius:50 \nangle:180\nPress to start.\n");
//		Button.waitForAnyPress();
//		robot.pilot.arc(50, 180);
//		
//		System.out.println("TEST 11: \narc \nradius:50 \nangle:90\nPress to start.\n");
//		Button.waitForAnyPress();
//		robot.pilot.arc(50, 90);
		
		
		robot.pilot.stop();
	}
	
}			
package navigator;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.navigation.Pose;


/*
 * Simples tests d'utilisation
 */
public class TestOdometrySimple1 {
	
	public static void main(String[] args) {
		int cptPose = 1, cptTest = 1;
		int x, y;
		RegulatedMotor moteurDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor moteurGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		
		Robot robot = new Robot(moteurGauche, moteurDroite);
	
		Pose pose;

		
		
		System.out.println("Ready to get Pose");
		Button.waitForAnyPress();				
		pose = robot.opp.getPose();		
		
		System.out.println("POSE " + cptPose++ + ":\n"
				+ "X:" + pose.getX());
//		System.out.println("POSE " + cptPose++ + ":\n" + pose);
		
//		System.out.println("TEST SQUARE: \ntravel 50cm\nrotate -90°\ntravel -50cm\nrotate -90°\ntravel 50cm\nrotate 90°\ntravel 50cm\nrotate 90°\nPress to start.\n");
//		Button.waitForAnyPress();		
//		robot.pilot.travel(50); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(-50); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(50); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
//		robot.pilot.travel(50); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
		
			
// TEST 1
			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second

//			System.out.println("Ready to get Pose");
//			Button.waitForAnyPress();				
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
			System.out.println("TEST " + cptTest++ +": \nrotate 90°\n");
			Button.waitForAnyPress();		
			robot.pilot.rotate(90);
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);
			
			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);
			
			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(-30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(-30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			
		robot.pilot.stop();
	}
	
}			
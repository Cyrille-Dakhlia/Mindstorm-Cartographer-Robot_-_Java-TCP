package navigator;

import lejos.hardware.Button;
import lejos.hardware.motor.Motor;
import lejos.robotics.navigation.Move;
import lejos.utility.Delay;
import lejos.robotics.chassis.Wheel;
import lejos.robotics.chassis.WheeledChassis;


public class mainTest {

	public static final double ECART_ROUES = 11.2;
	public static final double DIAMETRE_ROUE = 4.2;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Wheel wheel1 = WheeledChassis.modelWheel(Motor.A, DIAMETRE_ROUE).offset(-45.0);
		Wheel wheel2 = WheeledChassis.modelWheel(Motor.B, DIAMETRE_ROUE).offset(45.0);
		WheeledChassis chassis = new WheeledChassis(new Wheel[]{wheel1, wheel2}, WheeledChassis.TYPE_DIFFERENTIAL);	

		System.out.println("TestChassis");
		Button.waitForAnyPress();
		Move m = new Move(true, 180, 0);
		chassis.travel(150);
		while(chassis.isMoving());
		chassis.rotate(90);
		
		System.out.println(chassis.getDisplacement(m)+" "+chassis.isMoving());
		
		while(chassis.isMoving());
		System.out.println(chassis.getDisplacement(m)+" "+chassis.isMoving());
		
		chassis.arc(200, -90);

		while(chassis.isMoving());
		System.out.println(chassis.getDisplacement(m)+" "+chassis.isMoving());

		Button.waitForAnyPress();
	}

}

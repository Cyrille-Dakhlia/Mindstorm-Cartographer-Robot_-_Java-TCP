package navigator;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.geometry.Point;
import lejos.robotics.navigation.Pose;


/*
 * TEST : Déterminer la distance entre le robot et un Point fixé
 * OUTIL(S) : Pose.distanceTo(Point p);
 * RESULTAT : Succès. Opérationnel
 */
public class TestOdometryDestination {


	public static void main(String[] args) {
		int cptPose = 1, cptTest = 1;
		
		RegulatedMotor moteurDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor moteurGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		
		Robot robot = new Robot(moteurGauche, moteurDroite);
	
		Pose pose;

		Point p = new Point(50, 0);
		
		
		System.out.println("Ready to get Pose");
		Button.waitForAnyPress();				
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);

		System.out.println("Distance to p:\n" + pose.distanceTo(p) + " | 50");
		
//		System.out.println("TEST SQUARE: \ntravel 30cm\nrotate -90°\ntravel -30cm\nrotate -90°\ntravel 30cm\nrotate 90°\ntravel 30cm\nrotate 90°\nPress to start.\n");
//		Button.waitForAnyPress();		
//		robot.pilot.travel(30); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(-30); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(30); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
//		robot.pilot.travel(30); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
		

		
// TEST 1
			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			System.out.println("Distance to p:\n" + pose.distanceTo(p) + " | 20");

			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			System.out.println("Distance to p:\n" + pose.distanceTo(p) + " | (-)10");
		
				
// TEST 2
			System.out.println("TEST " + cptTest++ +": \nrotate 180°\nPress to start.\n");
			Button.waitForAnyPress();
			robot.pilot.rotate(180); // degree clockwise
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			System.out.println("Distance to p:\n" + pose.distanceTo(p) + " | (-)10");

			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);			

			System.out.println("Distance to p:\n" + pose.distanceTo(p) + " | 20");

			
			System.out.println("TEST " + cptTest++ +": \ntravel -30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(-30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);
	
			System.out.println("Distance to p:\n" + pose.distanceTo(p) + " | (-)10|50");
			

//// TEST 3
//			System.out.println("TEST " + cptTest++ +": \nrotate 90°\nPress to start.\n");
//			Button.waitForAnyPress();
//			robot.pilot.rotate(90); // degree clockwise
//			pose = robot.opp.getPose();		
//			System.out.println("POSE " + cptPose++ + ":\n" + pose);
//
//			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\nPress to start.\n");
//			Button.waitForAnyPress();		
//			robot.pilot.travel(30); // cm per second
//			pose = robot.opp.getPose();		
//			System.out.println("POSE " + cptPose++ + ":\n" + pose);			
//			
//			System.out.println("TEST " + cptTest++ +": \ntravel -30cm\nPress to start.\n");
//			Button.waitForAnyPress();		
//			robot.pilot.travel(-30); // cm per second
//			pose = robot.opp.getPose();		
//			System.out.println("POSE " + cptPose++ + ":\n" + pose);
			
	
		robot.pilot.stop();
	}
	
}			
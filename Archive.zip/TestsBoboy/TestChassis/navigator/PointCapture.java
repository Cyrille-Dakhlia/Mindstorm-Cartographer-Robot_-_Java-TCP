package navigator;

public class PointCapture {
	private double cartesian_x;
	private double cartesian_y;
	private float polar_distance;
	private float polar_angle;
	
	
	/****** DEBUT : CONSTRUCTEURS  ******/
//	public PointCapture(double x, double y) {
//		this.cartesian_x = x;
//		this.cartesian_y = y;
//	}
	
	public PointCapture(float distance, float angle) {
		this.polar_distance = distance; // en cm
		this.polar_angle = angle;
	}
	/****** FIN : CONSTRUCTEURS  ******/
	
	
	
	/****** DEBUT : ACCESSEURS  ******/
	public double getCartesianX() { return this.cartesian_x; }
	public double getCartesianY() { return this.cartesian_y; }
	public float getPolarDistance() { return this.polar_distance; }
	public float getPolarAngle() { return this.polar_angle; }
	
	public void setCartesianX(double x) { this.cartesian_x = x; }
	public void setCartesianY(double y) { this.cartesian_y = y; }
	public void setPolarDistance(float d) { this.polar_distance = d; }
	public void setPolarAngle(float a) { this.polar_angle = a; }
	/****** FIN : ACCESSEURS  ******/


	/****** DEBUT : FONCTIONS SUPPLEMENTAIRES  ******/
	/*
	 * RETURN : Retourne le point avec ses coordonnées cartésiennes complétées
	 */
	public void completeCartesianCoordinates() {
		// Conversion en radian par : rad = deg * pi / 180
		this.cartesian_x = this.polar_distance * Math.cos(this.polar_angle * Math.PI / 180); // On n'a pas besoin de corriger le signe car cos(theta) = cos(-theta)  (bien vu momo)
		this.cartesian_y = this.polar_distance * Math.sin(this.polar_angle * Math.PI / 180); // * -1); // On corrige le signe car le robot relève son orientation (heading) dans le sens anti-trigonométrique
	}


	
	/*
	 * FONCTION : Convertit un tableau de points en coordonnées polaires en un tableau de points en coordonnées cartésiennes
	 * ARGS : Tableau de float bidimensionnel contenant les coordonnées polaires des points avec les distances dans la 1ère ligne et les angles dans la 2nde
	 * RETURN : tableau de double bidimensionnel contenant dans la 1ère ligne les coordonnées en abscisse (cm) et dans la 2nde les coordonnées en ordonnée (cm)
	 */
	public static void completeCartesianCoordinatesTab(PointCapture[] capturePolaire) {
		for(int i=0 ; i<capturePolaire.length ; i++)
			capturePolaire[i].completeCartesianCoordinates();	
	}
	
	
	/*
	 * FONCTION : Convertit un tableau de points en coordonnées polaires en un tableau de points en coordonnées cartésiennes
	 * ARGS : Tableau de float bidimensionnel contenant les coordonnées polaires des points avec les distances dans la 1ère ligne et les angles dans la 2nde
	 * RETURN : tableau de double bidimensionnel contenant dans la 1ère ligne les coordonnées en abscisse (cm) et dans la 2nde les coordonnées en ordonnée (cm)
	 */
	public static double[][] getCartesianFromPolarCoordinates(float[][] capturePolaire) {
		double[][] captureCartesienne = new double[capturePolaire.length][capturePolaire[0].length];
		for(int i=0 ; i<capturePolaire[0].length ; i++) {
			captureCartesienne[0][i] = capturePolaire[0][i] * Math.cos(capturePolaire[1][i]); // Calcul de la coordonnée en x
			captureCartesienne[1][i] = capturePolaire[0][i] * Math.sin(capturePolaire[1][i]); // Calcul de la coordonnée en y
		}
		return captureCartesienne;
	}
	/****** DEBUT : FONCTIONS SUPPLEMENTAIRES  ******/

}

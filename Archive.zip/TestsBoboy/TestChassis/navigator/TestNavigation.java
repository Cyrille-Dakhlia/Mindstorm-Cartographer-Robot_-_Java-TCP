package navigator;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.geometry.Point;
import lejos.robotics.navigation.Pose;


/*
 * TEST : Navigation du robot tout au long d'un chemin parsemé de Waypoint fixés
 * OUTIL(S) : Classes Navigator, MovePilot, OdometryPoseProvider
 * RESULTAT : En attente...
 */
public class TestNavigation {


	public static void main(String[] args) {
		int cptPose = 1, cptTest = 1;
		
		RegulatedMotor moteurDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor moteurGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		Robot robot = new Robot(moteurGauche, moteurDroite);

		Pose pose;

		// POINT DESTINATION
		Point pointDestination = new Point(50, 0);

		System.out.println("Ready to get Pose");
		Button.waitForAnyPress();				
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);

		System.out.println("Distance to p:\n" + pose.distanceTo(pointDestination) + " | 50");

		
		System.out.println("Ready to\naddWayPoint(20, 0)");
		Button.waitForAnyPress();
		robot.nav.addWaypoint(20, 0);
		System.out.println("Ready to\nfollowPath");
		Button.waitForAnyPress();
		robot.nav.followPath();		
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);
		

		System.out.println("Ready to\naddWayPoint(40, 20)");
		Button.waitForAnyPress();
		robot.nav.addWaypoint(40, 20);
		System.out.println("Ready to\nfollowPath");
		Button.waitForAnyPress();
		robot.nav.followPath();		
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);


		System.out.println("Ready to\naddWayPoint(10, 20)");
		Button.waitForAnyPress();
		robot.nav.addWaypoint(10, 20);
		System.out.println("Ready to\nfollowPath");
		Button.waitForAnyPress();
		robot.nav.followPath();		
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);


		System.out.println("Ready to\naddWayPoint(10, 10)");
		Button.waitForAnyPress();
		robot.nav.addWaypoint(10, 10);
		System.out.println("Ready to\nfollowPath");
		Button.waitForAnyPress();
		robot.nav.followPath();		
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);

		System.out.println("Ready to\naddWayPoint(0, 0)");
		Button.waitForAnyPress();
		robot.nav.addWaypoint(0, 0, 0); // x=0 ; y=0 ; h=0
		System.out.println("Ready to\nfollowPath");
		Button.waitForAnyPress();
		robot.nav.followPath();		
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);

		
		robot.pilot.stop();
	}
	
}			
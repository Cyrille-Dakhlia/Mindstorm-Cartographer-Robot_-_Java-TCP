package navigator;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.geometry.Point;
import lejos.robotics.navigation.Pose;

/*
 * TEST : Evolution des coordonnées de l'objet OdometryPoseProvider lorsque le robot effectue une marche arrière
 * OUTIL(S) : MovePilot.travel(int < 0)
 * RESULTAT : Echec. Le robot ne compense pas (travel(50); travel(-50); donne une coordonnée à 100 au lieu de donner 0)
 */
public class TestOdometrySimple2 {
	private static final int ANGLE_MARCHE_ARRIERE_AXE_X = 180;
	private static final int ANGLE_MARCHE_ARRIERE_AXE_Y = 90;
	private static final int EPSILON = 5;

	public static void main(String[] args) {
		int cptPose = 1, cptTest = 1;
		
//			System.out.println("Ready to create Robot : press any key");
//			Button.waitForAnyPress();
		RegulatedMotor moteurDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor moteurGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		
		Robot robot = new Robot(moteurGauche, moteurDroite);
	
		Pose pose;
		
		
		System.out.println("Ready to get Pose");
		Button.waitForAnyPress();				
		pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);

		
//		System.out.println("TEST SQUARE: \ntravel 30cm\nrotate -90°\ntravel -30cm\nrotate -90°\ntravel 30cm\nrotate 90°\ntravel 30cm\nrotate 90°\nPress to start.\n");
//		Button.waitForAnyPress();		
//		robot.pilot.travel(30); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(-30); // cm per second
//		robot.pilot.rotate(-90); // degree clockwise
//		robot.pilot.travel(30); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
//		robot.pilot.travel(30); // cm per second
//		robot.pilot.rotate(90); // degree clockwise
		
		System.out.println("TEST " + cptTest++ +": \nrotate 360°\nPress to start.\n");
		Button.waitForAnyPress();
		robot.pilot.rotate(360); // degree clockwise
		 pose = robot.opp.getPose();		
		System.out.println("POSE " + cptPose++ + ":\n" + pose);

		
// TEST 1
			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);
			
			System.out.println("TEST " + cptTest++ +": \ntravel -30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(-30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);
		
				
// TEST 2
			System.out.println("TEST " + cptTest++ +": \nrotate 90°\nPress to start.\n");
			Button.waitForAnyPress();
			robot.pilot.rotate(90); // degree clockwise
			 pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);

			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);			
			
			System.out.println("TEST " + cptTest++ +": \ntravel -30cm\nPress to start.\n");
			Button.waitForAnyPress();		
			robot.pilot.travel(-30); // cm per second
			pose = robot.opp.getPose();		
			System.out.println("POSE " + cptPose++ + ":\n" + pose);
	
			

//// TEST 3
//			System.out.println("TEST " + cptTest++ +": \nrotate 90°\nPress to start.\n");
//			Button.waitForAnyPress();
//			robot.pilot.rotate(90); // degree clockwise
//			pose = robot.opp.getPose();		
//			System.out.println("POSE " + cptPose++ + ":\n" + pose);
//
//			System.out.println("TEST " + cptTest++ +": \ntravel 30cm\nPress to start.\n");
//			Button.waitForAnyPress();		
//			robot.pilot.travel(30); // cm per second
//			pose = robot.opp.getPose();		
//			System.out.println("POSE " + cptPose++ + ":\n" + pose);			
//			
//			System.out.println("TEST " + cptTest++ +": \ntravel -30cm\nPress to start.\n");
//			Button.waitForAnyPress();		
//			robot.pilot.travel(-30); // cm per second
//			pose = robot.opp.getPose();		
//			System.out.println("POSE " + cptPose++ + ":\n" + pose);
			
	
		robot.pilot.stop();
	}
	
}			
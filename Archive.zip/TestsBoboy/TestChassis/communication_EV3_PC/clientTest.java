package communication_EV3_PC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class clientTest {
	public String adressePC;
	public int portPC;
	public Socket socket;
	
	
	public static void main(String[] args) {
		try {
//			Socket socket = new Socket(PCServeur.ADRESSE_PC, PCServeur.PORT);
			Socket socket = new Socket("localhost", PCServeur.PORT);
			BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			pw.println("Hello serveur 7 :)");
			pw.flush();
			
			pw.close();		
			
			socket.close();
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public void transmission_donnees(String p) {
		try {
			
			this.socket = new Socket(this.adressePC, this.portPC);
			System.out.println("Connecté");
			BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			System.out.println("on va print");
			pw.println(p);
			pw.flush();
			System.out.println("on a printé");
			
			pw.close();		
			
			this.socket.close();
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}


	
}

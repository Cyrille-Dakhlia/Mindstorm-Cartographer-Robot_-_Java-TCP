package communication_EV3_PC;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.NXTUltrasonicSensor;
import lejos.robotics.RegulatedMotor;
import navigator.PointCapture;
import navigator.Robot;

public class TestCommunicationSimple {

	public static void main(String[] args) {

		RegulatedMotor roueDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor roueGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		NXTUltrasonicSensor sonar = new NXTUltrasonicSensor(SensorPort.S1);
		Robot robot = new Robot(roueGauche, roueDroite, sonar, PCServeur.ADRESSE_PC, PCServeur.PORT);
		
		System.out.println("adresse:" + robot.client.adressePC + "\n"
						+	"port:" + robot.client.portPC);
		
		System.out.println("\nReady for capture angle...");
		Button.waitForAnyPress();

		PointCapture p = robot.captureUnique_StructurePointCapture();
		System.out.println("(d= " + p.getPolarDistance() + ", a= " + p.getPolarAngle()
				+ "  |  (x= " + p.getCartesianX() + ", y= " + p.getCartesianY());		

		robot.client.transmission_donnees("   ROBOT : Hello serveur :)");
//		robot.client.transmission_donnees(p);
		
		/*** TEST POUR APRES (avec un tableau de PointCapture ***/
//		PointCapture[] capture = robot.captureAngle_StructurePointCapture(0);
//		System.out.println("     DEBUT AFFICHAGE");
//		for(int i=0 ; i<capture.length ; i++) {
//			System.out.print("(" + capture[i].getPolarDistance() + " cm, " + capture[i].getPolarAngle() + " deg)");
//			capture[i].completeCartesianCoordinates();
//			System.out.print(" | (" + capture[i].getCartesianX() + " cm, " + capture[i].getCartesianY() + " cm) -- ");
//		}
//		System.out.println("     FIN AFFICHAGE");



	}

}

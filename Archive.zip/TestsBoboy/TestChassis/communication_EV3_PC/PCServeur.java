package communication_EV3_PC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class PCServeur {
	public static final String ADRESSE_PC_0 = "10.0.2.15";
	public static final String ADRESSE_PC_1 = "10.0.1.3";
	public static final String ADRESSE_PC = "192.168.56.1";
	public static final int PORT = 4242;
	
	public static void main(String[] args) {
		
		
		ServerSocket server  ;
		Socket socket ;

		System.out.println("Let's start");
		
		try {
			server = new ServerSocket(PORT);
			while(true) {
				socket= server.accept(); 
				System.out.println("Connexion d'une socket");
				
				BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintWriter pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));

				String mess = br.readLine();
				System.out.println("Message reçu du client :\n" + mess);
				
			    
			    socket.close();

			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}

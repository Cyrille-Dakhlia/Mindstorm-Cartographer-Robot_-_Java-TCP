package movingKit;


import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.RegulatedMotorListener;


public class MovingKit {
	boolean record = false; 
	int rotateSpeed;
	RegulatedMotor rightWheel = new EV3LargeRegulatedMotor(MotorPort.A);
	RegulatedMotor leftWheel = new EV3LargeRegulatedMotor(MotorPort.B);
	public static final int GAUCHE = 0;
	public static final int DROITE = 1;
	
	public MovingKit() {
		rightWheel.addListener(new RegulatedMotorListener() {

			@Override
			public void rotationStarted(RegulatedMotor motor, int tachoCount,
					boolean stalled, long timeStamp) {
				// TODO Auto-generated method stub
				System.out.println("R-revolutioooon...");
				
			}

			@Override
			public void rotationStopped(RegulatedMotor motor, int tachoCount,
					boolean stalled, long timeStamp) {
				// TODO Auto-generated method stub
				System.out.println("... R has stopped");
			}
			
		});
		
		
		
		leftWheel.addListener(new RegulatedMotorListener() {

			@Override
			public void rotationStarted(RegulatedMotor motor, int tachoCount,
					boolean stalled, long timeStamp) {
				// TODO Auto-generated method stub
				System.out.println("L-revolutioooon...");
			}

			@Override
			public void rotationStopped(RegulatedMotor motor, int tachoCount,
					boolean stalled, long timeStamp) {
				// TODO Auto-generated method stub
				System.out.println("... L has stopped");
			}
			
		});
	}
	
	
	public void avancer() {
		
	}
	
	public void stopper() {
		
	}
	
	public void tourner(String flagDirection, int distance) {
		
	}
	// UTILISER LES VARIABLES ECRITES DANS L'ARCHITECTURE FAITE (gauche, droite, infinite, etc.)
	
}

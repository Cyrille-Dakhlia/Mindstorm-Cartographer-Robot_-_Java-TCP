package movingKit;

import lejos.robotics.RegulatedMotor;
import lejos.robotics.RegulatedMotorListener;


public class WheelListener implements RegulatedMotorListener {

	@Override
	public void rotationStarted(RegulatedMotor motor, int tachoCount,
			boolean stalled, long timeStamp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rotationStopped(RegulatedMotor motor, int tachoCount,
			boolean stalled, long timeStamp) {
		// TODO Auto-generated method stub
		
	}

}

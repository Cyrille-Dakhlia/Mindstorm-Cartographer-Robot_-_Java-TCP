package movingKit;

import lejos.hardware.lcd.LCD;
import lejos.utility.Delay;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LCD.drawString("Plugin Test", 0, 4);
		Delay.msDelay(5000);

	}

}

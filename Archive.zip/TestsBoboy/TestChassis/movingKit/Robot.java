package movingKit;


public class Robot {
	MovingKit movingKit;
	
	
	public Robot() {
		movingKit = new MovingKit();
	}
}

package captureSonar;

import java.util.ArrayList;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.NXTUltrasonicSensor;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.geometry.Point;
import lejos.robotics.navigation.Pose;
import navigator.PointCapture;
import navigator.Robot;


/* Vérifier si c'est ok <- METTRE LA FONCTION EN NON STATIC ET LA METTRE DANS CLASS ROBOT
 * Vérifier si c'est ok <- A CHAQUE CAPTURE, METTRE LA VALEUR DE HEADING COURANTE DANS LE TABLEAU DE FLOAT (tableau bidimensionnel)
 * ENLEVER LA FONCTION DE CAPTURE NE COMPRENANT PAS LES ANGLES (lorsqu'on sera sûr du résultat de celle avec les angles)
 */
public class CaptureSonar_Continue_StructurePointCapture {
		
	public static void main(String[] args) {
		RegulatedMotor roueDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor roueGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		NXTUltrasonicSensor sonar = new NXTUltrasonicSensor(SensorPort.S1);
		Robot robot = new Robot(roueGauche, roueDroite, sonar);

		
		System.out.println("\nReady for continual capture...");
		Button.waitForAnyPress();

//		robot.captureContinue_StructurePointCapture();
		robot.captureSimple_StructurePointCapture();
	}
}
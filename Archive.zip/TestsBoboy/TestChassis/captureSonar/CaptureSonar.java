package captureSonar;

import java.util.ArrayList;

import lejos.hardware.Button;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.NXTUltrasonicSensor;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.geometry.Point;
import lejos.robotics.navigation.Pose;
import navigator.PointCapture;
import navigator.Robot;


/* Vérifier si c'est ok <- METTRE LA FONCTION EN NON STATIC ET LA METTRE DANS CLASS ROBOT
 * Vérifier si c'est ok <- A CHAQUE CAPTURE, METTRE LA VALEUR DE HEADING COURANTE DANS LE TABLEAU DE FLOAT (tableau bidimensionnel)
 * ENLEVER LA FONCTION DE CAPTURE NE COMPRENANT PAS LES ANGLES (lorsqu'on sera sûr du résultat de celle avec les angles)
 */
public class CaptureSonar {
		
	public static void main(String[] args) {
		RegulatedMotor roueDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor roueGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		NXTUltrasonicSensor sonar = new NXTUltrasonicSensor(SensorPort.S1);
		Robot robot = new Robot(roueGauche, roueDroite, sonar);

		
		double aVit = robot.chassis.getAngularSpeed();
		System.out.println("Default angular speed = " + aVit);
		
		System.out.println("\nReady for capture angle...");
		Button.waitForAnyPress();
		
		
		/*** TEST 2 BIS : EN ATTENTE ***/
		robot.chassis.setAngularSpeed(20);
		float[][] capturePolaire = robot.captureAngle(90);
		System.out.println("     DEBUT AFFICHAGE");
//		for(float[] fTab : capturePolaire) { // On affiche d'abord les distances, puis les angles.
//			for(float f : fTab)
//				System.out.print(f + " ");
//			System.out.println();
//		}
		for(int i=0 ; i<capturePolaire[0].length ; i++) {
			System.out.print(capturePolaire[0][i] + " cm | " + capturePolaire[1][i] + " deg");
			System.out.println();
		}
		System.out.println();
		System.out.println("     FIN AFFICHAGE");
		
		
		System.out.println("\nReady for capture angle BIS...");
		Button.waitForAnyPress();
		
		robot.chassis.setAngularSpeed(aVit);
		
		/*** TEST 2 BIS : EN ATTENTE ***/
		float[][] capturePolaireBis = robot.captureAngle(-90);
		System.out.println("     DEBUT AFFICHAGE BIS");
//		for(float[] fTab : capturePolaireBis) { // On affiche d'abord les distances, puis les angles.
//			for(float f : fTab)
//				System.out.print(f + " ");
//			System.out.println();
//		}
		for(int i=0 ; i<capturePolaireBis[0].length ; i++) {
			System.out.print(capturePolaireBis[0][i] + " cm | " + capturePolaireBis[1][i] + " deg");
			System.out.println();
		}
		System.out.println();
		System.out.println();
		System.out.println("     FIN AFFICHAGE BIS");

		
		System.out.println("\nConversion des coordonnées polaires en coordonnées cartésiennes...");
		Button.waitForAnyPress();
		double[][] captureCartesienne = PointCapture.getCartesianFromPolarCoordinates(capturePolaire);
		for(int i=0 ; i<captureCartesienne[0].length ; i++) {
			System.out.println("(" + captureCartesienne[0][i] + ", "
									+ captureCartesienne[1][i] + ")");
		}
		
//		System.out.println("Press when ready...");
//		Button.waitForAnyPress();
//	
//		/*** TEST 1 : SUCCES ***/
//		float[] capture1 = capture360(robot);  // METTRE LA FONCTION EN NON STATIC ET LA METTRE DANS CLASS ROBOT
//		System.out.println("     DEBUT AFFICHAGE 1");
//		for(float f : capture1)
//			System.out.print(f + " ");
//		System.out.println();
//		System.out.println("     FIN AFFICHAGE 1");
//
//		
//		System.out.println("\nReady for capture BIS...");
//		Button.waitForAnyPress();
//		
//		
//		/*** TEST 1 BIS : EN ATTENTE ***/
//		float[] capture1Bis = robot.capture360();
//		System.out.println("     DEBUT AFFICHAGE 1 BIS");
//		for(float f : capture1Bis)
//			System.out.print(f + " ");
//		System.out.println();
//		System.out.println("     FIN AFFICHAGE 1 BIS");
//
//
//		
//		
//		System.out.println("\nReady for capture angle...");
//		Button.waitForAnyPress();
//		
//		
//		/*** TEST 2 : EN ATTENTE ***/
//		float[][] captureAngle = capture360Angle(robot);
//		System.out.println("     DEBUT AFFICHAGE AVEC ANGLE");
//		for(float[] fTab : captureAngle) { // On récupère d'abord les distances, puis les angles.
//			for(float f : fTab)
//				System.out.print(f + " ");
//			System.out.println();
//		}
//		System.out.println();
//		System.out.println("     FIN AFFICHAGE AVEC ANGLE");

		
		
		
		
		
		
		
		
//		System.out.println("     DEBUT AFFICHAGE 2");
//		for(int i=0 ; i<capture1.length ; i++)
//			System.out.print(capture1[i] + " ");
//		System.out.println("     FIN AFFICHAGE 2");

		
		
		/* Debut : Test 1 */
//		float[] sample = new float[robot.distanceProvider.sampleSize()];
//		System.out.println("size = " + sample.length);
//		Button.waitForAnyPress();
//		while(true) {
//			robot.distanceProvider.fetchSample(sample, 0);
//			System.out.println(sample[0]);
//		}
		/* Fin : Test 1 */

		
		/* Debut : Test 2 */
//		ArrayList<Float> sampleList = new ArrayList<Float>();
//		while(true) {
//			robot.distanceProvider.fetchSample(sample, 0);
//			sampleList.add(sample[0]);
//		}
		/* Fin : Test 2 */
		
	}

	
	
	
//	public static float[][] capture360Angle(Robot robot) {
//		System.out.println("     DEBUT CAPTURE360&Angle");
//		float[] sample = new float[robot.distanceProvider.sampleSize()];
////		float[] sample = new float[360];
//		ArrayList<Float> sampleList = new ArrayList<Float>();
//		ArrayList<Float> angleList = new ArrayList<Float>();
//		
//		robot.pilot.rotate(360, true); // immediate return = true
//		while(robot.pilot.isMoving()) {
//			robot.distanceProvider.fetchSample(sample, 0);
//			sampleList.add(sample[0]);
//			angleList.add(robot.opp.getPose().getHeading());
//		}
//		System.out.println("sampleSize = " + sampleList.size());
//		System.out.println("angleSize = " + angleList.size());
//		
//		float[][] sampleReturn = new float[2][sampleList.size()];
//		for(int i=0 ; i<sampleList.size() ; i++) {
//			sampleReturn[0][i] = sampleList.get(i);
//			sampleReturn[1][i] = angleList.get(i);
//		}
//		System.out.println("     FIN CAPTURE360");
//		
//		return sampleReturn;		
//	}
//	
//	
//	public static float[] capture360(Robot robot) {
//		System.out.println("     DEBUT CAPTURE360");
//		float[] sample = new float[robot.distanceProvider.sampleSize()];
////		float[] sample = new float[360];
//		ArrayList<Float> sampleList = new ArrayList<Float>();
//
//		robot.pilot.rotate(360, true); // immediate return = true
//		while(robot.pilot.isMoving()) {
//			robot.distanceProvider.fetchSample(sample, 0);
//			sampleList.add(sample[0]);
//		}
//		System.out.println("size = " + sampleList.size());
//		
//		float[] sampleReturn = new float[sampleList.size()];
//		for(int i=0 ; i<sampleList.size() ; i++)
//			sampleReturn[i] = sampleList.get(i);
//		System.out.println("     FIN CAPTURE360");
//		
//		return sampleReturn;		
//	}

}

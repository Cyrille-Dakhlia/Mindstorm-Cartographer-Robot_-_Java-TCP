import lejos.hardware.Button;
import lejos.hardware.motor.Motor;
import lejos.robotics.navigation.Move;
import lejos.utility.Delay;
import lejos.robotics.chassis.Wheel;
import lejos.robotics.chassis.WheeledChassis;

public class TestChassis {

   public static void main(String[] args) {   
      
       Wheel wheel1 = WheeledChassis.modelWheel(Motor.A, 55.0).offset(-45.0).invert(false);
       Wheel wheel2 = WheeledChassis.modelWheel(Motor.D, 55.0).offset(45.0).invert(false);
       WheeledChassis chassis = new WheeledChassis(new Wheel[] { wheel1, wheel2 }, WheeledChassis.TYPE_DIFFERENTIAL);
        System.out.println("TestChassis");
        Button.waitForAnyPress();
        Move m = new Move(true, 180,0);
      chassis.travel(150);
      while(chassis.isMoving());
      chassis.rotate(90);
      System.out.println(chassis.getDisplacement(m)+" "+chassis.isMoving());
        while(chassis.isMoving());
       System.out.println(chassis.getDisplacement(m)+" "+chassis.isMoving());
       chassis.arc(200, -90);
       while(chassis.isMoving());
       System.out.println(chassis.getDisplacement(m)+" "+chassis.isMoving());
         Button.waitForAnyPress();         
   }

}


//Output redirected
//Executing jrun -cp /home/lejos/programs/TestChassis.jar lejos.internal.ev3.EV3Wrapper TestChassis in /home/lejos/programs
//java.lang.ClassNotFoundException: lejos.robotics.chassis.Wheel
//	at java.net.URLClassLoader$1.run(URLClassLoader.java:366)
//	at java.net.URLClassLoader$1.run(URLClassLoader.java:355)
//	at java.security.AccessController.doPrivileged(Native Method)
//	at java.net.URLClassLoader.findClass(URLClassLoader.java:354)
//	at java.lang.ClassLoader.loadClass(ClassLoader.java:425)
//	at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308)
//	at java.lang.ClassLoader.loadClass(ClassLoader.java:358)
//	at java.lang.Class.forName0(Native Method)
//	at java.lang.Class.forName(Class.java:190)
//	at lejos.internal.ev3.EV3Wrapper.invokeClass(EV3Wrapper.java:51)
//	at lejos.internal.ev3.EV3Wrapper.main(EV3Wrapper.java:46)


   
//	   Button.waitForAnyPress();
//	   System.out.println("---------- DEBUT TEST");
//	   RegulatedMotor moteurDroite = new EV3LargeRegulatedMotor(MotorPort.A);
//	   RegulatedMotor moteurGauche = new EV3LargeRegulatedMotor(MotorPort.B);
//	   
//	   System.out.println("---------- MID TEST");
//	   
//	   Wheel wheel1 = WheeledChassis.modelWheel(moteurDroite, 55.0);
//	   Motor.A.forward();
//	   Button.waitForAnyPress();
//	   System.out.println("---------- FIN TEST");
   
   
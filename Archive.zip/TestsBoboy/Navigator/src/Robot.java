//import lejos.robotics.navigation.DifferentialPilot;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.chassis.Chassis;
import lejos.robotics.chassis.Wheel;
import lejos.robotics.chassis.WheeledChassis;
import lejos.robotics.navigation.MovePilot;


public class Robot {
//	DifferentialPilot pilot;
	public MovePilot pilot;
	public Chassis chassis;

	public static final String UNITE = "cm";
	public static final double ECART_ROUES = 11.2;
	public static final double DIAMETRE_ROUE = 4.2;
	
	public Robot(RegulatedMotor roueGauche, RegulatedMotor roueDroite) {
		System.out.println("Test Robot");
		System.getProperty("java.classpath");
		
		Wheel leftWheel = WheeledChassis.modelWheel(roueGauche, DIAMETRE_ROUE).offset( -(ECART_ROUES/2) );
		Wheel rightWheel = WheeledChassis.modelWheel(roueDroite, DIAMETRE_ROUE).offset(ECART_ROUES/2);
		chassis = new WheeledChassis(new Wheel[]{leftWheel, rightWheel}, WheeledChassis.TYPE_DIFFERENTIAL);
		
		pilot = new MovePilot(chassis);
	}


}

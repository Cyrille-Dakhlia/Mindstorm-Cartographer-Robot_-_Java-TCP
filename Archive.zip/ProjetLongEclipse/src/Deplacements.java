/*import lejos.hardware.*;
import lejos.hardware.motor.*;
import lejos.hardware.port.*;
import lejos.hardware.sensor.NXTUltrasonicSensor;
import lejos.robotics.SampleProvider;

public class Deplacements {

	EV3LargeRegulatedMotor roueDroite;
	EV3LargeRegulatedMotor roueGauche;
	//NXTUltrasonicSensor ult = new NXTUltrasonicSensor(MotorPort.B);
	final static int DROITE = 1;
	final static int GAUCHE = 2;

	public Deplacements(EV3LargeRegulatedMotor roueDroite,EV3LargeRegulatedMotor roueGauche){
		this.roueDroite = roueDroite;
		this.roueGauche = roueGauche;
	}

	public void avancer(float d){
		int angle_distance = (int)((360*d)/(Math.PI*4.3));
		this.roueDroite.rotate(angle_distance);
		this.roueGauche.rotate(angle_distance);
	}

	void tournerAvecObstacle(int flag){

		//SampleProvider sample;
		float[] tmp = new float[1];
		//sample = ult.getDistanceMode();
		//sample.fetchSample(tmp,0);
		System.out.println(tmp[0]+"");
		while(tmp[0] != Float.POSITIVE_INFINITY){
			if(flag == DROITE)
				tourner(DROITE);
			else if(flag == GAUCHE)
				tourner(GAUCHE);
		}
		this.stop();
	}

	void stop(){
		this.roueDroite.stop();
		this.roueGauche.stop();
	}
	
	void tourner(int flag){
		while(true){
			if(flag == GAUCHE){

				this.roueDroite.forward();
				this.roueGauche.backward();
			}
			else if(flag == DROITE){
				this.roueDroite.backward();
				this.roueGauche.forward();
			}
		}
	}
	void tourner(int flag, float angle){
		int angle_rot = (int)(angle*15/4.3);
		if(flag == GAUCHE){
			this.roueDroite.rotate(angle_rot);
			this.roueGauche.rotate(-angle_rot);
		}
		else if(flag == DROITE){
			this.roueDroite.rotate(-angle_rot);
			this.roueGauche.rotate(angle_rot);
		}
	}

	void reculer(float d){
		int angle_distance = (int)((360*d)/(Math.PI*4.3));
		this.roueDroite.rotate(-angle_distance);
		this.roueGauche.rotate(-angle_distance);
	}

	public static void main(String[] args){
		float speed = 1000;
		EV3LargeRegulatedMotor roueDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		EV3LargeRegulatedMotor roueGauche = new EV3LargeRegulatedMotor(MotorPort.C);
		Deplacements dep = new Deplacements(roueDroite,roueGauche);

		roueDroite.setSpeed(speed);
		dep.avancer(20); //avancer de 20 cm
		//dep.tourner(DROITE, 90); //tourner a droite de 90 degrès
		Button.waitForAnyPress();
	}
}*/
package communication_EV3_PC;

import java.io.Serializable;

import navigator.PointCapture;

public class DonneesGraphiques implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final double MAX_VALUE = 255;
	public double xMin;
	public double yMin;
	public PointCapture[] capture;
		
	public DonneesGraphiques(PointCapture[] p) {
		this.capture = p;
		this.xMin = 0;
		this.yMin = 0;
		for(PointCapture point : p) {
			this.xMin = (point.getCartesianX() < this.xMin && Math.abs(point.getCartesianX()) <= MAX_VALUE)? point.getCartesianX() : this.xMin;
			this.yMin = (point.getCartesianY() < this.yMin && Math.abs(point.getCartesianX()) <= MAX_VALUE)? point.getCartesianY() : this.yMin;
		}
	}
	
	
	
}

package communication_EV3_PC;

import javafx.application.*;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.scene.*;
import javafx.scene.shape.*;
import javafx.scene.control.*;
import javafx.scene.canvas.*;
import javafx.event.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.beans.property.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import navigator.PointCapture;
//METTRE CA AVEC LE PASSAGE D'UN PARAMETRE DonneesGraphiques AU LIEU de PointCapture[]
//METTRE LES CHAMPS TABLEAU DANS CarteToile3 et 

/* DANS CE FICHIER : 
   ======> RECEVOIR LA CARTE (int[][]) ET LE GRAPHE (ArrayList<Sommet>);
*/

/* APPELLER refresh(carte,graphe); */

public class PCClient_tmp {

    private void refresh(int[][] carte, Graphe graphe){
	PixelWriter pw = gc.getPixelWriter();
	for (int i=0; i<W; i++) {
	    for (int j=0; j<H; j++) {
		if (carte[i][j] == -1) {
		    pw.setColor(i,j,Color.MAGENTA);
		}
		if (carte[i][j] == 0) {
		    pw.setColor(i,j,Color.BLACK);
		}
		if (carte[i][j] == 1) {
		    pw.setColor(i,j,Color.WHITE);
		}
		if (carte[i][j] == 2) {
		    pw.setColor(i,j,Color.RED);
		}
		if (carte[i][j] == -3) {
		    pw.setColor(i,j,Color.PURPLE);
		}
		if (carte[i][j] == -2) {
		    pw.setColor(i,j,Color.YELLOW);
		}
	    }
	}
	/*for (Sommet s : graphe) {
	    drawSommet(s);
	    for (Sommet v : s.voisins) {
		drawSommet(v);
		drawLine(s,v);
	    }
	    }*/
    }

    public void drawSommet(Sommet s) {
	gc.setStroke(Color.BLUE);
	gc.setLineWidth(2.0);
	gc.strokeOval((double)s.getX()-10,(double)s.getY()-10,20,20);
	gc.setLineWidth(1.0);
    }

    public void drawLine(Sommet s1, Sommet s2) {
	gc.setStroke(Color.BLUE);
	gc.setLineWidth(2.0);
	gc.strokeLine((double)s1.getX(),(double)s1.getY(),(double)s2.getX(),(double)s2.getY());
	gc.setLineWidth(1.0);
    }
    
	public static void main(String[] args) {
		
		try {
			Socket socket = new Socket("10.0.1.1", Constantes.PORT);
			System.out.println("Connexion d'une socket");
			
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
					
	
//			PointCapture[] p = (PointCapture[])in.readObject();
//			for(int i=0 ; i<p.length ; i++) 
//				System.out.println("(d= " + p[i].getPolarDistance() + ", a= " + p[i].getPolarAngle()
//						+ "  <=>  (x= " + p[i].getCartesianX() + ", y= " + p[i].getCartesianY() + ")");		
//			Cartographie carte = new Cartographie(p);
//			carte.repaint();

			DonneesGraphiques data = (DonneesGraphiques)in.readObject();
			for(int i=0 ; i<data.capture.length ; i++) 
				System.out.println("(d= " + data.capture[i].getPolarDistance() + ", a= " + data.capture[i].getPolarAngle()
						+ "  <=>  (x= " + data.capture[i].getCartesianX() + ", y= " + data.capture[i].getCartesianY() + ")");		

			
			CartographieDonneesGraphiques carte = new CartographieDonneesGraphiques(data);
			
			socket.close();
							
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}

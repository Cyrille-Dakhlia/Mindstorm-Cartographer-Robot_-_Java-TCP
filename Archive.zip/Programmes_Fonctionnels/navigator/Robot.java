package navigator;

//import lejos.robotics.navigation.DifferentialPilot;
import java.util.ArrayList;

import communication_EV3_PC.DonneesGraphiques;
import communication_EV3_PC.EV3Client;
import communication_EV3_PC.EV3Serveur_tmp;

import lejos.hardware.Button;
import lejos.hardware.sensor.NXTUltrasonicSensor;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.SampleProvider;
import lejos.robotics.chassis.Chassis;
import lejos.robotics.chassis.Wheel;
import lejos.robotics.chassis.WheeledChassis;
import lejos.robotics.localization.OdometryPoseProvider;
import lejos.robotics.navigation.MovePilot;
import lejos.robotics.navigation.Navigator;


/*
 * 1. METTRE LES CHAMPS EN PRIVE LORSQUE TOUT SERA FONCTIONNEL
 * 2. POUR RECULER ON PREFERERA FAIT "rotate(180); travel(distance)" AFIN DE GARDER LES COORDONNEES DE L'OdometryPoseProvider A JOUR (car il ne prend pas en compte les déplacements arrières)
 */
public class Robot {
	//	public int x; // Coordonnée en abscisse
	//	public int y; // Coordonnée en ordonnée
	//	public int h; // Angle auquel le robot fait face par rapport à sa position de départ
	public MovePilot pilot;
	public Chassis chassis;
	public OdometryPoseProvider opp;
	public Navigator nav;

	public NXTUltrasonicSensor sonar;
	public SampleProvider distanceProvider;
	//	public SampleProvider pingProvider;    // Ne mesure que des échos toujours plus grand

	public EV3Client client;
	public EV3Serveur_tmp server;

	public static final String UNITE = "cm";
	public static final double EPSILON = 0.7; //0.55; //1.1; //0.8; //0.55; //0; //0.8; //0.7; //0.6; //0.59;
	public static final double ECART_ROUES = 11.20 - EPSILON; //10.61; //10.62; //11.2; //10.7; //10.75; //10.8; //10.6; //20; //11.2;
	public static final double DIAMETRE_ROUE = 4.2; //10;

	ArrayList<Sommet> liste = new ArrayList<Sommet>(); //graphe renvoyé par le pc
	PointCapture[] captureTotale;

	/******************** DEBUT : CONSTRUCTEURS  ********************/
	// Constructeur avec roues (sans sonar et sans connexion PC)
	public Robot(RegulatedMotor roueGauche, RegulatedMotor roueDroite) {	
		//		Wheel leftWheel = WheeledChassis.modelWheel(roueGauche, DIAMETRE_ROUE).offset( (ECART_ROUES/2) );
		//		Wheel rightWheel = WheeledChassis.modelWheel(roueDroite, DIAMETRE_ROUE).offset( -(ECART_ROUES/2) );

		Wheel leftWheel = WheeledChassis.modelWheel(roueGauche, DIAMETRE_ROUE).offset( -(ECART_ROUES/2) );
		Wheel rightWheel = WheeledChassis.modelWheel(roueDroite, DIAMETRE_ROUE).offset(ECART_ROUES/2);
		chassis = new WheeledChassis(new Wheel[]{leftWheel, rightWheel}, WheeledChassis.TYPE_DIFFERENTIAL);
		pilot = new MovePilot(chassis);
		opp = new OdometryPoseProvider(pilot);
		nav = new Navigator(pilot, opp);
	}

	// Constructeur avec roues et avec sonar (sans connexion PC)
	public Robot(RegulatedMotor roueGauche, RegulatedMotor roueDroite, NXTUltrasonicSensor _sonar) {
		Wheel leftWheel = WheeledChassis.modelWheel(roueGauche, DIAMETRE_ROUE).offset( -(ECART_ROUES/2) );
		Wheel rightWheel = WheeledChassis.modelWheel(roueDroite, DIAMETRE_ROUE).offset(ECART_ROUES/2);
		chassis = new WheeledChassis(new Wheel[]{leftWheel, rightWheel}, WheeledChassis.TYPE_DIFFERENTIAL);		
		pilot = new MovePilot(chassis);
		opp = new OdometryPoseProvider(pilot);
		nav = new Navigator(pilot, opp);
		sonar = _sonar;
		distanceProvider = sonar.getDistanceMode();
		//		pingProvider = sonar.getPingMode();
	}

	// Constructeur avec roues, avec sonar et avec connexion PC (EV3 Client, PC Serveur)
	public Robot(RegulatedMotor roueGauche, RegulatedMotor roueDroite, NXTUltrasonicSensor _sonar, String adresse, int port) {
		Wheel leftWheel = WheeledChassis.modelWheel(roueGauche, DIAMETRE_ROUE).offset( -(ECART_ROUES/2) );
		Wheel rightWheel = WheeledChassis.modelWheel(roueDroite, DIAMETRE_ROUE).offset(ECART_ROUES/2);
		chassis = new WheeledChassis(new Wheel[]{leftWheel, rightWheel}, WheeledChassis.TYPE_DIFFERENTIAL);		
		pilot = new MovePilot(chassis);
		opp = new OdometryPoseProvider(pilot);
		nav = new Navigator(pilot, opp);
		sonar = _sonar;
		distanceProvider = sonar.getDistanceMode();
		//		pingProvider = sonar.getPingMode();

		client = new EV3Client(adresse, port);
	}


	// Constructeur avec roues, avec sonar et avec connexion PC (EV3 Serveur, PC Client)
	public Robot(RegulatedMotor roueGauche, RegulatedMotor roueDroite, NXTUltrasonicSensor _sonar, int port) {
		Wheel leftWheel = WheeledChassis.modelWheel(roueGauche, DIAMETRE_ROUE).offset( -(ECART_ROUES/2) );
		Wheel rightWheel = WheeledChassis.modelWheel(roueDroite, DIAMETRE_ROUE).offset(ECART_ROUES/2);
		chassis = new WheeledChassis(new Wheel[]{leftWheel, rightWheel}, WheeledChassis.TYPE_DIFFERENTIAL);		
		pilot = new MovePilot(chassis);
		opp = new OdometryPoseProvider(pilot);
		nav = new Navigator(pilot, opp);
		sonar = _sonar;
		distanceProvider = sonar.getDistanceMode();
		//		pingProvider = sonar.getPingMode();

		server = new EV3Serveur_tmp(port);
	}

	/******************** FIN : CONSTRUCTEURS  ********************/




	/******************** DEBUT : ACCESSEURS  ********************/
	//	public int getX() { return this.x; }
	//	public int getY() { return this.y; }
	//	public int getH() { return this.h; }
	//	
	//	public void setX(int x) { this.x = x; }
	//	public void setY(int y) { this.y = y; }
	//	public void setH(int h) { this.h = h; }
	/******************** FIN : ACCESSEURS  ********************/




	/******************** DEBUT : FONCTIONS  ********************/

	/*** DEBUT : AVEC STRUCTURE PointCapture ***/
	/*
	 * RETURN : tableau de float bidimensionnel contenant dans la 1ère ligne les distances (cm) et dans la 2nde les angles (°)
	 */
	public PointCapture[] captureAngle_StructurePointCapture(int angle, int vitesse) {
		System.out.println("     DEBUT captureAngle_StructurePointCapture");
		this.pilot.setAngularSpeed(vitesse);
		float[] sample = new float[this.distanceProvider.sampleSize()]; // taille = 1 : permet de récupérer les valeurs du sonar
		ArrayList<PointCapture> pointCaptureList = new ArrayList<PointCapture>();

		// On ajoute la position du robot
		pointCaptureList.add(
				new PointCapture(0,
						this.opp.getPose().getHeading(),
						this.opp.getPose().getX(),
						this.opp.getPose().getY(),
						true));

		// On procede a la rotation du robot et a l'enregistrement des donnees
		this.pilot.rotate(angle, true); // immediate return = true
		while(this.pilot.isMoving()) {
			this.distanceProvider.fetchSample(sample, 0);
			// on ajoute dans la liste un nouveau PointCapture avec (distance en cm (= "*100"), angle)
			//			pointCaptureList.add(new PointCapture(sample[0]*100, this.opp.getPose().getHeading()));
			pointCaptureList.add(
					new PointCapture(sample[0]*100,
							this.opp.getPose().getHeading(),
							this.opp.getPose().getX(),
							this.opp.getPose().getY()));

		}
		System.out.println("PointCaptureSize = " + pointCaptureList.size());

		PointCapture[] pointCaptureReturn = new PointCapture[pointCaptureList.size()];
		for(int i=0 ; i<pointCaptureList.size() ; i++) {
			pointCaptureReturn[i] = pointCaptureList.get(i);
			pointCaptureReturn[i].completeCartesianCoordinates();
		}
		System.out.println("     FIN captureAngle_StructurePointCapture");
		return pointCaptureReturn;		
	}
	/*** FIN : AVEC STRUCTURE PointCapture ***/


	/*** DEBUT : SANS STRUCTURE PointCapture ***/
	/*
	 * RETURN : tableau de float bidimensionnel contenant dans la 1ère ligne les distances (cm) et dans la 2nde les angles (°)
	 */
	public float[][] captureAngle(int angle) {
		System.out.println("     DEBUT CAPTURE360&Angle");
		float[] sample = new float[this.distanceProvider.sampleSize()];
		ArrayList<Float> sampleList = new ArrayList<Float>();
		ArrayList<Float> angleList = new ArrayList<Float>();

		this.pilot.rotate(angle, true); // immediate return = true
		while(this.pilot.isMoving()) {
			this.distanceProvider.fetchSample(sample, 0);
			sampleList.add(sample[0]);
			angleList.add(this.opp.getPose().getHeading());
		}
		System.out.println("sampleSize = " + sampleList.size());
		System.out.println("angleSize = " + angleList.size());

		float[][] sampleReturn = new float[2][sampleList.size()];
		for(int i=0 ; i<sampleList.size() ; i++) {
			sampleReturn[0][i] = sampleList.get(i)*100; // conversion en cm
			sampleReturn[1][i] = angleList.get(i);
		}

		System.out.println("     FIN CAPTURE360");
		return sampleReturn;		
	}
	/*** FIN : SANS STRUCTURE PointCapture ***/









	/*** TMP ***/
	public void captureContinue_StructurePointCapture() {
		System.out.println("     DEBUT captureContinue_StructurePointCapture");
		float[] sample = new float[this.distanceProvider.sampleSize()]; // taille  = 1 : permet de récupérer les valeurs du sonar
		ArrayList<PointCapture> pointCaptureList = new ArrayList<PointCapture>();
		int i = 0;
		while(i < 10000) {
			if(i%500 == 0)
				this.pilot.rotate(90);
			this.distanceProvider.fetchSample(sample, 0);
			pointCaptureList.add(new PointCapture(sample[0]*100, this.opp.getPose().getHeading()));
			PointCapture p = pointCaptureList.get(i++);
			p.completeCartesianCoordinates();
			System.out.println("(d= " + p.getPolarDistance() + ", a= " + p.getPolarAngle()
			+ "  |  (x= " + p.getCartesianX() + ", y= " + p.getCartesianY());

		}
		System.out.println("pointCaptureList Size = " + pointCaptureList.size());

		System.out.println("     FIN captureContinue_StructurePointCapture");
	}

	public void captureSimple_StructurePointCapture() {
		System.out.println("     DEBUT captureSimple_StructurePointCapture");
		float[] sample = new float[this.distanceProvider.sampleSize()]; // taille  = 1 : permet de récupérer les valeurs du sonar
		ArrayList<PointCapture> pointCaptureList = new ArrayList<PointCapture>();

		int i = 0;		
		while(i < 4) {
			System.out.println("Press when ready");
			Button.waitForAnyPress();
			this.distanceProvider.fetchSample(sample, 0);
			pointCaptureList.add(new PointCapture(sample[0]*100, this.opp.getPose().getHeading())); // on multiplie par 100 pour avoir la distance en cm
			PointCapture p = pointCaptureList.get(i++);
			p.completeCartesianCoordinates();
			System.out.println("(d= " + p.getPolarDistance() + ", a= " + p.getPolarAngle()
			+ "  |  (x= " + p.getCartesianX() + ", y= " + p.getCartesianY());
			this.pilot.rotate(90);
		}
		System.out.println("pointCaptureList Size = " + pointCaptureList.size());

		System.out.println("     FIN captureSimple_StructurePointCapture");
	}
	/*** TMP ***/



	/*** TMP 2 ***/
	public PointCapture captureUnique_StructurePointCapture() { //boolean ping) {
		System.out.println("     DEBUT captureUnique_StructurePointCapture");
		float[] sample;
		//		if(ping)
		//			sample = new float[8];
		//		else
		sample = new float[this.distanceProvider.sampleSize()]; // taille  = 1 : permet de récupérer les valeurs du sonar
		ArrayList<PointCapture> pointCaptureList = new ArrayList<PointCapture>();

		//		if(ping)
		//			this.pingProvider.fetchSample(sample, 0);
		//		else
		this.distanceProvider.fetchSample(sample, 0);

		//		if(ping) {
		//			System.out.println("AFFICHAGE PING");
		//			for(int i=0 ; i<8 ; i++) {
		//				System.out.print(sample[i]*100 + " | ");
		//			}
		//		}
		pointCaptureList.add(new PointCapture(sample[0]*100, this.opp.getPose().getHeading())); // on multiplie par 100 pour avoir la distance en cm
		PointCapture p = pointCaptureList.get(0);
		p.completeCartesianCoordinates();
		System.out.println("     FIN captureUnique_StructurePointCapture");
		return p;
	}


	public void captureUnique() {
		System.out.println("     DEBUT captureUnique");
		float[] sample = new float[this.distanceProvider.sampleSize()];
		ArrayList<Float> sampleList = new ArrayList<Float>();
		ArrayList<Float> angleList = new ArrayList<Float>();

		this.distanceProvider.fetchSample(sample, 0);
		sampleList.add(sample[0]);
		angleList.add(this.opp.getPose().getHeading());

		float[][] sampleReturn = new float[2][sampleList.size()];
		for(int i=0 ; i<sampleList.size() ; i++) {
			sampleReturn[0][i] = sampleList.get(i)*100; // conversion en cm
			sampleReturn[1][i] = angleList.get(i);
		}


		double cartesian_x = sampleReturn[0][0] * Math.cos(sampleReturn[1][0]); // On n'a pas besoin de corriger le signe car cos(theta) = cos(-theta)  (bien vu momo)
		double cartesian_y = sampleReturn[0][0] * Math.sin(sampleReturn[1][0]); // On corrige le signe car le robot relève son orientation (heading) dans le sens anti-trigonométrique
		double cartesian_y2 = sampleReturn[0][0] * Math.sin(sampleReturn[1][0] *-1); // On corrige le signe car le robot relève son orientation (heading) dans le sens anti-trigonométrique


		System.out.println("(d= " + sampleReturn[0][0] + ", a= " + sampleReturn[1][0]
				+ "  |  (x= " + cartesian_x + ", y= " + cartesian_y);		
		System.out.println("(d= " + sampleReturn[0][0] + ", a= " + sampleReturn[1][0]
				+ "  |  (x= " + cartesian_x + ", y2= " + cartesian_y2);		


		System.out.println("     FIN captureUnique");
	}

	/*** TMP 2 ***/


	
	
	
	
	/******  DEBUT FONCTION DEPLACEMENT DANS LE GRAPHE **********/
	public static PointCapture[] fusion(PointCapture[]... captures) {
		int tailleTotale = 0;
		for(PointCapture[] pc : captures) {
			tailleTotale += pc.length;
		}
		
		PointCapture[] captureTotale = new PointCapture[tailleTotale];
		
		int cpt = 0;
		for(PointCapture[] pc : captures) {
			for(int i=0 ; i<pc.length ; i++) {
				captureTotale[cpt++] = pc[i];
			}
		}
		return captureTotale;
	}	
	
	
	public void deplacement_graphe(){
		
		for(Sommet s : this.liste){     // Pour tous les sommets du graphe 
			if(!s.isVisite()){          // si le sommet n'est pas visité
				deplacement_sommet(s);  // on se déplace dessus
				s.setVisite(true);      // on le marque etant visité
				
				//faire un scan (cette fonction doit prendre en paramètre la liste pour pouvoir en rajouter des nouveaux ou en supprimer)
				this.scan(s);
			}
		}
	}
	
	public void deplacement_sommet(Sommet s){
		
		this.nav.goTo(s.getX(), s.getY());
		
		//mettre une boucle a evenement (thread) pour verifier que le robot ne rencontre pas d'obstacle (capteur de touché)
		//deplacer le robot jusqua ces coordonnées
		//si les coordonnées ne conviennent pas il faut corrigé ( a faire )
	}
	
	public void scan(Sommet courrant){
		final int ANGLE = 360;
		final int VITESSE = 20;
		
		PointCapture[] capture = this.captureAngle_StructurePointCapture(ANGLE, VITESSE);
		
		this.captureTotale = fusion(capture);
		
		//ici appliquer l algo de benji pour voir si il y a des issues ( prend en argument le PointCapture[] )
		//si l algo a trouvé des nouvelles issues on les rajoutent, si il a trouvé un cul de sac on le retire
		
		DonneesGraphiques data = new DonneesGraphiques(this.captureTotale);
		System.out.println("[SCAN] data xMin = " + data.xMin + "\ndata yMin = " + data.yMin);
		this.server.transmission_donnees(data);
	}
	
	/******  FIN FONCTION DEPLACEMENT DANS LE GRAPHE  ***********/


	/******************** FIN : FONCTIONS  ********************/
}
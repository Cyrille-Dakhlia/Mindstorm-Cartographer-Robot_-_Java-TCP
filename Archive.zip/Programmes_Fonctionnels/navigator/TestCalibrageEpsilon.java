package navigator;

import java.awt.Button;

import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.RegulatedMotor;

public class TestCalibrageEpsilon {

	public static void main(String[] args) {
		RegulatedMotor roueDroite = new EV3LargeRegulatedMotor(MotorPort.A);
		RegulatedMotor roueGauche = new EV3LargeRegulatedMotor(MotorPort.B);
		
		Robot robot = new Robot(roueGauche, roueDroite);		
		System.out.println(robot.opp.getPose());
		
		

//		for(int i=0 ; i<0 ; i++) {
//			robot.pilot.travel(5);
//			robot.pilot.setAngularSpeed(20);
//	
//			robot.pilot.rotate(180);
//			System.out.println(robot.opp.getPose());
//			
//	//		robot.pilot.setLinearSpeed(2);
//	//		robot.pilot.setAngularSpeed(40);
//			robot.pilot.travel(5);
//			
//	//		System.out.println("Press when ready...");
//	//		Button.waitForAnyPress();		
//			robot.pilot.rotate(180);
//			System.out.println(robot.opp.getPose());
//		}

//		for(int i=0 ; i<4 ; i++) {
//			robot.pilot.travel(5);
//			robot.pilot.setAngularSpeed(40);
//	
//			robot.pilot.rotate(-180);
//			System.out.println(robot.opp.getPose());
//			
//	//		robot.pilot.setLinearSpeed(2);
//	//		robot.pilot.setAngularSpeed(40);
//			robot.pilot.travel(5);
//			
//	//		System.out.println("Press when ready...");
//	//		Button.waitForAnyPress();		
//			robot.pilot.rotate(-180);
//			System.out.println(robot.opp.getPose());
//		}
		
		final int ANGLE = 360;
		final int VITESSE = 40;
		
		for(int i=0 ; i<2 ; i++) {
			robot.pilot.travel(5);
			robot.pilot.setAngularSpeed(VITESSE);
	
			robot.pilot.rotate(ANGLE);
			System.out.println(robot.opp.getPose());
			
			robot.pilot.travel(5);
			
			robot.pilot.rotate(ANGLE);
			System.out.println(robot.opp.getPose());

			robot.pilot.travel(5);
			robot.pilot.rotate(90);

		}
		
		
	}

}

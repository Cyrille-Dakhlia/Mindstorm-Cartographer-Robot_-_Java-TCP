package communication_EV3_PC;

import javafx.application.*;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.scene.*;
import javafx.scene.shape.*;
import javafx.scene.control.*;
import javafx.scene.canvas.*;
import javafx.event.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.beans.property.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import objets_cartographie.CartographieDonneesGraphiques;
import objets_cartographie.DonneesGraphiques;
import robot.Constantes;
import tmp.Graphe;
import tmp.Sommet;

import navigator.PointCapture;
//METTRE CA AVEC LE PASSAGE D'UN PARAMETRE DonneesGraphiques AU LIEU de PointCapture[]
//METTRE LES CHAMPS TABLEAU DANS CarteToile3 et 


public class PCClient_tmp {

    
	public static void main(String[] args) {
		
		try {
			Socket socket = new Socket("10.0.1.1", Constantes.PORT);
			System.out.println("Connexion d'une socket");
			
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
					
			DonneesGraphiques data = (DonneesGraphiques)in.readObject();

//			for(int i=0 ; i<data.capture.length ; i++) 
//				System.out.println("(d= " + data.capture[i].getPolarDistance() + ", a= " + data.capture[i].getPolarAngle()
//						+ "  <=>  (x= " + data.capture[i].getCartesianX() + ", y= " + data.capture[i].getCartesianY() + ")");		

			
			CartographieDonneesGraphiques carte = new CartographieDonneesGraphiques(data);
			
			socket.close();
							
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}

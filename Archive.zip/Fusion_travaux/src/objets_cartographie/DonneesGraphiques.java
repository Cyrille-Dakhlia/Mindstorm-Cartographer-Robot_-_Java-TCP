package objets_cartographie;

import java.io.Serializable;
import tmp.Graphe;

public class DonneesGraphiques implements Serializable {

	private static final long serialVersionUID = 1L;

	private int[][] carte;
	private Graphe graphe;
	
	
	
	public DonneesGraphiques(int[][] carte, Graphe graphe) {
		this.carte = carte;
		this.graphe = graphe;
	}

	
	public int[][] getCarte() { return this.carte; }
	public Graphe getGraphe() { return this.graphe; }
		
}

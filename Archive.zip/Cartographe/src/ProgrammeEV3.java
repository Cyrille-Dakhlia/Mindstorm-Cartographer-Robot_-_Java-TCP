import lejos.hardware.Button;

public class ProgrammeEV3 {

	public static void main(String[] args) {
		Robot robot = new Robot();
		(new Thread(new EV3Server(robot))).start();
		double angle = 360.0;
		Button.waitForAnyPress();
		robot.tourner(Robot.GAUCHE, (float)angle);
	}
}

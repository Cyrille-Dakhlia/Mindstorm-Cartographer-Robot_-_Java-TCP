	
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;	
import javax.swing.JFrame;
import javax.swing.JPanel;
	
public class Graphique extends JFrame{

	private static final long serialVersionUID = 1L;
	Container cont = null;
	Panneau pan = null;
	PCClient pcc;
	float val;
			
	class Panneau extends JPanel{
		private static final long serialVersionUID = 1L;
		
		public void paintComponent(Graphics g){
			if(pcc.l != null){
				for(int i=0; i < pcc.l.size(); i++){
					int a = pcc.l.get(i)[0];
					int b = pcc.l.get(i)[1];
					System.out.println(a);
					System.out.println(b);
					g.setColor(Color.BLUE);
					g.drawRect(a, b, 2, 2);
					g.fillRect(a, b, 2, 2);
				}
			}
		}
	}

	public Graphique(){
		super("carte pièce");
		setSize(700,700);
		cont = getContentPane();
		pan = new Panneau();
		cont.add(pan);
		pcc = new PCClient(pan);
		Thread t = new Thread(pcc);
		t.start();
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}


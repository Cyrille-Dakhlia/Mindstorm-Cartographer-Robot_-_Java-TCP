import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;


public class EV3Server implements Runnable {
	public static final int port = 1234;
	Robot robot;
	
	public EV3Server(Robot b){
		robot = b;
	}
	
	@Override
	public void run(){
		try{
			int i = 1;
			ServerSocket server = new ServerSocket(port);
			System.out.println("Attente de connexion...");
			Socket client = server.accept();
			System.out.println("Connecte");
			ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
			while(i>0){
				if(Robot.send){
					out.writeObject(Robot.send);
					out.writeObject(robot.list_resultante);
					break;
				}
				//out.writeInt(robot.xSonar);
				//out.writeInt(robot.ySonar);
				//out.flush();
			}
			out.flush();
			server.close();
		} catch(IOException e){}
	}
}

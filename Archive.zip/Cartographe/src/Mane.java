import javax.swing.JFrame;

public class Mane {

	public static void main(String[] args) {
		new Graphique();
	}

}

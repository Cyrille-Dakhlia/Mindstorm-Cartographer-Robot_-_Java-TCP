import java.util.ArrayList;
import java.util.List;

import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.NXTUltrasonicSensor;

public class Robot {
	NXTUltrasonicSensor sonar = null;
	Roue leftWheel = null;
	Roue rightWheel = null;
	float angleRobot;
	List<int[]> list_resultante = null;
	static boolean send = false;
	
	public static final int POSX_SONAR = 5;
	public static final int POSY_SONAR = 7;
	public static final int ECART_ROUES = 11;
	public static final int DIAMETRE_ROUE = 4;
	public static final int GAUCHE = 0;
	public static final int DROITE = 1;
	
	private class Roue{
		EV3LargeRegulatedMotor motor;
		int x;
		int y;
		
		public Roue(EV3LargeRegulatedMotor m, int xx, int yy){
			motor = m;
			x = xx;
			y = yy;
			motor.setSpeed(100);
		}
		
		public void tourner(float angle){
			motor.rotateTo((int)angle);
		}
	}
	
	public Robot(){
		sonar = new NXTUltrasonicSensor(SensorPort.S1);
		leftWheel = new Roue(new EV3LargeRegulatedMotor(MotorPort.B),350,350);
		rightWheel = new Roue(new EV3LargeRegulatedMotor(MotorPort.A),350 + ECART_ROUES,350);
		angleRobot = 90;
	}
	
	private float toRad(float angle){
		return (float) (Math.PI*angle/180.0);
	}
	
	public void tourner(int flag, float angle){
		float pas;
		int angle_rot = (int) ((toRad(angle)*(float)ECART_ROUES)/((float)Math.PI*(float)DIAMETRE_ROUE)*360.0);
		System.out.println(angle_rot);
		int i = 0;
		int[] tab;
		int xSonar;
		int ySonar;
		double alpha;
		double omega = Math.atan((double)POSY_SONAR/(double)POSX_SONAR)*180.0/Math.PI;
		int AB = (int)(Math.sqrt((double)(POSX_SONAR*POSX_SONAR)+(double)(POSY_SONAR*POSY_SONAR)));
		List<Float> list_entree;
		Thread t;
		try{
			list_entree = new ArrayList<Float>();
			list_resultante = new ArrayList<int[]>();
			GetDistanceTask task = new GetDistanceTask(sonar,list_entree);
			t = new Thread(task);
			t.start();
			if(flag == GAUCHE){
				rightWheel.tourner(angle_rot);
				task.stop = true;
				t.join();
				System.out.println(list_entree);
				pas = angle/list_entree.size();
				for (float theta = angleRobot; theta <= angleRobot + angle && i < list_entree.size(); theta += pas) {
					tab = new int[2];
					rightWheel.x = leftWheel.x + (int)(ECART_ROUES*Math.cos(toRad(theta-90)));
					rightWheel.y = leftWheel.y - (int)(ECART_ROUES*Math.sin(toRad(theta-90)));
					alpha = omega + (double)(theta - 90);
					xSonar = leftWheel.x + (int)(AB*Math.cos(toRad((float)alpha)));
					ySonar = leftWheel.y - (int)(AB*Math.sin(toRad((float)alpha)));
					tab[0] = xSonar + (int)(list_entree.get(i)*100*Math.cos(toRad(theta)));
					tab[1] = ySonar - (int)(list_entree.get(i)*100*Math.sin(toRad(theta)));
					list_resultante.add(tab);
					i++;
				}
				angleRobot += angle;
				send = true;
			}
			if(flag == DROITE){
				leftWheel.tourner(angle_rot);
				task.stop = true;
				leftWheel.x = rightWheel.x + (int)(ECART_ROUES*Math.cos(angleRobot - angle));
				leftWheel.y = rightWheel.y - (int)(ECART_ROUES*Math.sin(angleRobot - angle));
				angleRobot -= angle;
			} 
		} catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}

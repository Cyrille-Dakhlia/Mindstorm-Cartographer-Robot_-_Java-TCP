import java.net.Socket;
import java.util.Arrays;
import java.util.List;
import java.io.IOException;
import java.io.ObjectInputStream;

public class PCClient implements Runnable {
	List<int[]> l = null;
	Graphique.Panneau pan;
		
	public PCClient(Graphique.Panneau p){
		pan = p;
	}
	
	@Override
	public void run() {
		try{
			boolean send = false;
			String ip = "10.0.1.1";
			Socket sock = new Socket(ip,EV3Server.port);
			ObjectInputStream in = new ObjectInputStream(sock.getInputStream());
			int i = 1;
			while(i > 0){
				try{
					send = (boolean)in.readObject();
					if(send){
						Object o = in.readObject();
						l = (List<int[]>)o;
						break;
					}
				}catch(Exception e){}/*finally{
					pan.repaint();
				}*/
			}
			pan.repaint();
			sock.close();
		}catch(Exception e){}
	}
	
}

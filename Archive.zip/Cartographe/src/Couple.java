
public class Couple {
	int x, y;
	
	public Couple(int xx, int yy){
		x=xx;
		y=yy;
	}
	
	public String toString(){
		return "(" + x + "," + y + ")";
	}
}

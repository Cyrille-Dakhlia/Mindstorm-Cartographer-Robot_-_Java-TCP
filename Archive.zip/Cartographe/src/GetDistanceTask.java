import java.util.List;
import lejos.hardware.sensor.NXTUltrasonicSensor;
import lejos.robotics.SampleProvider;

public class GetDistanceTask implements Runnable {
	NXTUltrasonicSensor sonar = null;
	List<Float> list_distances = null;
	boolean stop = false;
	SampleProvider sample = null;
	float[] mesure = null;
	
	public GetDistanceTask(NXTUltrasonicSensor son, List<Float> ld){
		sonar = son;
		list_distances = ld;
		sample = sonar.getDistanceMode();
		mesure = new float[1];
	}
	
	private float getDistance(){
		sample.fetchSample(mesure, 0);
		return mesure[0];
	}
	
	@Override
	public void run() {
		while(!stop){
			list_distances.add(getDistance());
		}
	}
}

package calculs;

import java.util.ArrayList;

public class Graphe extends ArrayList<Sommet> {
}

package robot;

public class Constantes {
	public static final String ADRESSE_PC_0 = "10.0.2.15";
	public static final String ADRESSE_PC_1 = "10.0.1.3";
	public static final String ADRESSE_PC = "192.168.56.1";
	public static final int PORT = 4242;

}
